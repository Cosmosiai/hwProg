package hw1.oop;

public class Oop23 {
}
