package hw1.oop;

public class Relax {
    static int id;
    private String type;
    private double commission;
    private int days;
    private boolean food;
    private String transport;

    public Relax(String type, double commission, int days, boolean food, String transport) {
        this.type = type;
        this.commission = commission;
        this.days = days;
        this.food = food;
        this.transport = transport;
        id++;
    }

    @Override
    public String toString() {
        return "Relax{" +
                "type='" + type + '\'' +
                ", commission=" + commission +
                ", days=" + days +
                ", food=" + food +
                ", transport='" + transport + '\'' +
                '}';
    }

    public static Relax random() {
        return null;
    }

    public String getType() {
        return type;
    }

    public double getCommission() {
        return commission;
    }

    public int getDays() {
        return days;
    }

    public boolean isFood() {
        return food;
    }

    public String getTransport() {
        return transport;
    }
}
